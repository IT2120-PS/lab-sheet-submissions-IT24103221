setwd("C:\\Users\\it24103221\\Desktop\\IT24103221")

#The distribution of X is a Binomial distribution.
#The random variable X represents the number of students 
#who passed the test out of 50. n = 50 and p = 0.85

n <- 50
p <- 0.85

1 - pbinom(46, 50, 0.85, lower.tail = TRUE)
pbinom(46, 50, 0.85, lower.tail = FALSE)


#The random variable X is the number of 
#customer calls received in an hour

#ii.The distribution of X is 
#a Poisson distribution.
#The average rate is 12 calls per hour

lambda <- 12

#Find P(X=15).
dpois(15, 12)