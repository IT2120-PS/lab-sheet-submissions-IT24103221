setwd("C:\\Users\\Dell\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24103221")

#Question 01
prob_q1 <- punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)
print(paste("Probability for Q1 (Uniform):", prob_q1))

#Question 02
lambda_q2 <- 1/3
prob_q2 <- pexp(2, rate = lambda_q2, lower.tail = TRUE)
print(paste("Probability for Q2 (Exponential):", prob_q2))

#Question03 - i
mean_q3 <- 100
sd_q3 <- 15
prob_q3_i <- pnorm(130, mean = mean_q3, sd = sd_q3, lower.tail = FALSE)
print(paste("Probability for Q3 (i) (IQ above 130):", prob_q3_i))

#Question03 - ii
percentile_q3_ii <- qnorm(0.95, mean = mean_q3, sd = sd_q3)
print(paste("IQ score for Q3 (ii) (95th percentile):", percentile_q3_ii))