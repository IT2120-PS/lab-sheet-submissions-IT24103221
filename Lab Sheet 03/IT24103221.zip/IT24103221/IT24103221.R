#Importing the Dataset
student_data <- read.csv("Exercise.csv", header=TRUE)

#Summary Statistics and Histogram for Age (X1)
summary(student_data$X1)
hist(student_data$X1, main="Histogram for Age", xlab="Age", ylab="Frequency")

#Bar Chart and Frequency Table for Gender (X2)
gender_freq <- table(student_data$X2)
gender_freq

#Bar Chart
gender_freq_labels <- c("Male", "Female")
barplot(gender_freq, main="Bar Chart for Gender", xlab="Gender", ylab="Frequency", names.arg=gender_freq_labels)

#Analyzing Age (X1) and Accommodation (X3)
accommodation_labels <- c("Type 1", "Type 2", "Type 3")
boxplot(student_data$X1 ~ student_data$X3, main="Boxplots for Age by Accommodation", xlab="Accommodation", ylab="Age", names=accommodation_labels)